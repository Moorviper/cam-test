mod clipper;
pub mod debug;

#[cfg(test)]
mod tests;

pub use clipper::*;
